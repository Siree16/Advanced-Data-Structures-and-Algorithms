#include <stdbool.h>
#include <stdio.h>


int minimumColors(int N,int E,int U[],int V[])
{
    int adj[N][N]; 
    int colors[N]; 

    for(int i=0;i<N;i++)
    {
        colors[i]=0;
        for(int j=0;j<N;j++)
        {
            adj[i][j]=0;
        }
    }

    for(int i=0;i<E;i++)
    {
        adj[U[i]-1][V[i]-1]=1;
        adj[V[i]-1][U[i]-1]=1;
    }

    for(int u=0;u<N;u++)
    {
        bool usedColors[N];
        for(int i=0;i<N;i++)
        {
            usedColors[i]=false;
        }

        for(int v=0;v<N;v++)
        {
            if(adj[u][v] && colors[v]!=0)
            {
                usedColors[colors[v]-1]=true;
            }
        }

        int smallestColor=1;
        while(usedColors[smallestColor-1])
        {
            smallestColor++;
        }

        colors[u]=smallestColor;
    }

    int maxColor=0;
    for (int i=0;i<N;i++)
    {
        if(colors[i]>maxColor)
        {
            maxColor=colors[i];
        }
    }

    return maxColor;
}

int main()
{
    // int N = 5, E = 8;
    // int U[] = {1, 1, 2, 2, 3, 3, 4, 5};
    // int V[] = {2, 3, 1, 4, 1, 5, 2, 3};
    

    // int N = 50, E = 84;
    // int U[] = {37, 16, 36, 43, 22, 28, 10, 27, 27, 37, 19, 30, 31, 24, 36, 3, 9, 18, 7, 43, 24, 20, 38, 25, 21, 27, 31, 24, 21, 32, 26, 28, 6, 30, 8, 46, 46, 18, 15, 1, 9, 29, 35, 2, 50, 11, 19, 13, 37, 40, 21, 29, 2, 3, 43, 7, 31, 42, 40, 20, 30, 18, 22, 26, 28, 7, 4, 16, 34, 25, 22, 30, 20, 19, 16, 50, 24, 46, 2, 6, 39, 29, 1, 1};
    // int V[] = {28, 44, 37, 50, 13, 41, 14, 41, 23, 12, 18, 33, 13, 18, 30, 23, 20, 44, 12, 30, 22, 35, 49, 16, 14, 42, 7, 13, 47, 6, 35, 37, 47, 14, 25, 33, 15, 35, 44, 38, 27, 39, 4, 5, 33, 27, 40, 27, 45, 46, 35, 18, 48, 18, 3, 2, 37, 16, 45, 41, 32, 48, 32, 10, 18, 48, 37, 7, 20, 29, 33, 4, 21, 9, 41, 47, 19, 47, 22, 30, 15, 42, 44, 35};

int N,E;
scanf("%d %d",&N,&E);

int num=E;
int U[num];
int V[num];

for(int i=0;i<num;i++)
{
    scanf("%d",&U[i]);
}
for(int i=0;i<num;i++)
{
    scanf("%d",&V[i]);
}
    int minColor=minimumColors(N,E,U,V);
    printf("%d",minColor);


    return 0;
}
