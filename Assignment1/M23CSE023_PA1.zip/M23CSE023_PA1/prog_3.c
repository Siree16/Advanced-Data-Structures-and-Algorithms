#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <limits.h>
#define NUM_VERTICES 6
typedef struct node
{
    int key;
    int distance;
    bool isRed;
    struct node *left, *right, *parent;
}node;

typedef struct red_black_tree
{
    node *root_node;
}red_black_tree;


struct node* create_node(int key,int distance)
{
    struct node *new_node=(node *)malloc(sizeof(node));
    new_node->key=key;
    new_node->distance=distance;
    new_node->isRed=true;
    new_node->left=NULL;
    new_node->right=NULL; 
    new_node->parent=NULL;
    return new_node;
}


void left_rotate_red_black_tree(struct red_black_tree *tree,struct node *x)
{
    struct node *y=x->right;
    x->right=y->left;
    if(y->left!=NULL)
    {
        y->left->parent=x;
    }
    y->parent=x->parent;
    if (x->parent =NULL)
    {
        tree->root_node=y;
    }
    else if(x==x->parent->left)
    {
        x->parent->left=y;
    }
    else
    {
        x->parent->right=y;
    }
    y->left=x;
    x->parent=y;
}


void right_rotate_red_black_tree(struct red_black_tree *tree,struct node *y)
{
    struct node *x=y->left;
    y->left=x->right;
    if(x->right!=NULL)
    {
        x->right->parent=y;
    }
    x->parent=y->parent;
    if(y->parent==NULL)
    {
        tree->root_node=x;
    }
    else if(y==y->parent->left)
    {
        y->parent->left=x;
    }
    else
    {
        y->parent->right=x;
    }
    x->right=y;
    y->parent=x;
}

void insert_red_black_tree(struct red_black_tree *tree,int key,int distance)
{
    struct node *newnode=create_node(key,distance);
    struct node *parent=NULL;
    struct node *current=tree->root_node;
    while(current!=NULL)
    {
        parent=current;
        if(newnode->key<current->key)
        {
            current=current->left;
        }
        else
        {
            current=current->right;
        }
    }
    newnode->parent=parent;
    if(parent==NULL)
    {
        tree->root_node=newnode;
    }
    else if(newnode->key<parent->key)
    {
        parent->left = newnode;
    }
    else
    {
        parent->right=newnode;
    }

    while(newnode!=tree->root_node && newnode->parent->isRed)
    {
        if(newnode->parent==newnode->parent->parent->left)
        {
            node *uncle=newnode->parent->parent->right;
            if(uncle!=NULL && uncle->isRed)
            {
                newnode->parent->isRed=false;
                uncle->isRed=false;
                newnode->parent->parent->isRed=true;
                newnode=newnode->parent->parent;
            }
            else
            {
                if(newnode==newnode->parent->right)
                {
                    newnode=newnode->parent;
                    left_rotate_red_black_tree(tree,newnode);
                }
                newnode->parent->isRed=false;
                newnode->parent->parent->isRed=true;
                right_rotate_red_black_tree(tree,newnode->parent->parent);
            }
        }
        else
        {
            struct node *uncle=newnode->parent->parent->left;
            if(uncle!=NULL && uncle->isRed)
            {
                newnode->parent->isRed=false;
                uncle->isRed=false;
                newnode->parent->parent->isRed=true;
                newnode=newnode->parent->parent;
            }
            else
            {
                if(newnode==newnode->parent->left)
                {
                    newnode=newnode->parent;
                    right_rotate_red_black_tree(tree,newnode);
                }
    
                newnode->parent->isRed=false;
                newnode->parent->parent->isRed=true;
                left_rotate_red_black_tree(tree,newnode->parent->parent);
            }
        }
    }


    tree->root_node->isRed=false;
}

struct node* successor(node *node)
{
    if(node->right!=NULL)
    {
        node=node->right;
        while(node->left!=NULL)
        {
            node=node->left;
        }
        return node;
    }
    struct node *parent=node->parent;
    while(parent!=NULL && node==parent->right)
    {
        node=parent;
        parent=parent->parent;
    }

    return parent;
}


void delete_fixup_red_black_tree(struct red_black_tree *tree,node *x,node *xParent)
{
    while(x!=tree->root_node && (x==NULL || !x->isRed))
    {
        if (x==xParent->left)
        {
            node *w = xParent->right;
            if(w->isRed)
            {
                w->isRed=false;
                xParent->isRed=true;
                left_rotate_red_black_tree(tree,xParent);
                w=xParent->right;
            }
            if((w->left==NULL || !w->left->isRed) &&
                (w->right==NULL || !w->right->isRed))
                {
                w->isRed=true;
                x=xParent;
                xParent=xParent->parent;
            } 
            else
            {
                if(w->right==NULL || !w->right->isRed)
                {
                   
                    if(w->left !=NULL)
                    {
                        w->left->isRed=false;
                    }
                    w->isRed=true;
                    right_rotate_red_black_tree(tree,w);
                    w=xParent->right;
                }

                w->isRed=xParent->isRed;
                xParent->isRed=false;
                if(w->right !=NULL)
                {
                    w->right->isRed=false;
                }
                left_rotate_red_black_tree(tree,xParent);
                x=tree->root_node; 
            }
             }
             else
             {  
            node *w=xParent->left;
            if(w->isRed)
            {
                              w->isRed=false;
                xParent->isRed=true;
                right_rotate_red_black_tree(tree,xParent);
                w=xParent->left;
            }

            if((w->right==NULL || !w->right->isRed) &&
                (w->left==NULL || !w->left->isRed))
                {
                w->isRed=true;
                x=xParent;
                xParent=xParent->parent;
            }
            else
            {
                if(w->left==NULL || !w->left->isRed)
                {
                                        if(w->right != NULL)
                                        {
                        w->right->isRed=false;
                    }
                    w->isRed=true;
                    left_rotate_red_black_tree(tree,w);
                    w=xParent->left;
                }

                w->isRed=xParent->isRed;
                xParent->isRed=false;
                if (w->left!=NULL)
                {
                    w->left->isRed=false;
                }
                right_rotate_red_black_tree(tree,xParent);
                x=tree->root_node;
            }
        }
    }

    if(x!=NULL)
    {
        x->isRed=false;
    }
}

void delete_red_black_tree(struct red_black_tree *tree,struct node *node_del)
{
    node *node_fix;
    if(node_del->left==NULL || node_del->right==NULL)
    {
        node_fix=node_del;
    }
    else
    {
        node_fix=successor(node_del);
        //here I am finding inorder successor
    }

    struct node *child=(node_fix->left != NULL) ? node_fix->left : node_fix->right;

    if(child != NULL)
    {
        child->parent=node_fix->parent;
    }
    if(node_fix->parent==NULL)
    {
        tree->root_node=child;
    }
    else if(node_fix==node_fix->parent->left)
    {
        node_fix->parent->left=child;
    }
    else
    {
        node_fix->parent->right=child;
    }
    if (node_fix!=node_del)
    {
        node_del->key=node_fix->key;
    }
    if (!node_fix->isRed)
    {
        delete_fixup_red_black_tree(tree,child,node_fix->parent);
    }
    free(node_fix);
}

void dij_red_black(int graph[][NUM_VERTICES],int source,int dest_target,int numVertices)
{
    struct red_black_tree priority_queue=
    { .root_node=NULL };

    int distances[NUM_VERTICES];
    for (int i=0;i<NUM_VERTICES;i++)
    {
        distances[i]=INT_MAX;
    }
    distances[source]=0;
    insert_red_black_tree(&priority_queue,source,distances[source]);

    while(priority_queue.root_node !=NULL)
    {

        struct node *currentnode=priority_queue.root_node;
        while(currentnode->left!=NULL)
        {
            currentnode = currentnode->left;
        }
        int currentVertex = currentnode->key;
        delete_red_black_tree(&priority_queue,currentnode);

        for(int neighbor=0;neighbor<numVertices;neighbor++)
        {
            if(graph[currentVertex][neighbor] != 0)
            {
                int newDistance=distances[currentVertex]+graph[currentVertex][neighbor];
                if (newDistance < distances[neighbor])
                {
                    distances[neighbor] = newDistance;

                    
                    insert_red_black_tree(&priority_queue, neighbor, newDistance);
                }
            }
        }
    }
    printf("Shortest distance from %d to %d: %d\n", source, dest_target, distances[dest_target]);
}

int main() {
    int numVertices = 6;
    int graph[6][6] = {
        {0, 7, 0, 0, 0, 0},
        {7, 0, 9, 0, 0, 14},
        {0, 9, 0, 10, 0, 0},
        {0, 0, 10, 0, 11, 0},
        {0, 0, 0, 11, 0, 2},
        {0, 14, 0, 0, 2, 0}
    };
    int source = 0;
    int dest_target = 2;

    dij_red_black(graph, source, dest_target, numVertices);

    return 0;
}
