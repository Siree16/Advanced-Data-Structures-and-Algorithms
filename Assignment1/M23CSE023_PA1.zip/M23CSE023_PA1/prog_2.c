#include <stdio.h>
#include <stdlib.h>
struct node_of_bst {
    int data;
    struct node_of_bst* left;
    struct node_of_bst* right;
};
struct node_of_bst* new_node_of_bst(int data)
{
    struct node_of_bst* new_node_of_bst = (struct node_of_bst*)malloc(sizeof(struct node_of_bst));
    new_node_of_bst->data = data;
    new_node_of_bst->left = NULL;
    new_node_of_bst->right = NULL;
    return new_node_of_bst;
}

struct node_of_bst* insert(struct node_of_bst* root, int data) {
    if (root == NULL)
    {
        return new_node_of_bst(data);
    }
    if(data<root->data)
    {
        root->left=insert(root->left, data);
    }
    else if(data>root->data)
    {
        root->right = insert(root->right, data);
    }
    return root;
}

void inorder(struct node_of_bst* root) {
    if(root!=NULL)
    {
        inorder(root->left);
        printf(" %d ", root->data);
        inorder(root->right);
    }
}
struct node_of_bst* min(struct node_of_bst* node_of_bst)
{
    while(node_of_bst->left != NULL)
    {
        node_of_bst = node_of_bst->left;
    }
    return node_of_bst;
}
struct node_of_bst* delete(struct node_of_bst* root,int data)
{
    if (root == NULL)
    {
        return root;
    }
    if(data<root->data)
    {
        root->left=delete(root->left, data);
    }
    else if(data>root->data)
    {
        root->right=delete(root->right, data);
    }else
    {
        if (root->left == NULL)
        {
            struct node_of_bst* temp=root->right;
            free(root);
            return temp;
        }
        else if(root->right==NULL)
        {
            struct node_of_bst* temp = root->left;
            free(root);
            return temp;
        }
        // 2 children-inorder successor
        struct node_of_bst* temp=min(root->right);
        root->data=temp->data;
        root->right=delete(root->right,temp->data);
    }
    return root;
}
int search_bst(struct node_of_bst* root,int key)
{
    if(root==NULL)
    {
        return -1;
    }
    if(key==root->data)
    {
        return root->data;
    }
    else if(key<root->data)
    {
        return search_bst(root->left,key);
    }
    else
    {
        return search_bst(root->right,key);
    }
}
void swap(int *a,int *b)
{
    int temp=*a;
    *a=*b;
    *b=temp;
}
void find_wrong_node_of_bsts(struct node_of_bst* root,struct node_of_bst** behind,struct node_of_bst** first, struct node_of_bst** second) {
    if(root == NULL)
    {
      return;
    }
    find_wrong_node_of_bsts(root->left,behind,first,second);
    if(*behind!=NULL && root->data<(*behind)->data)
    {
        if(*first==NULL)
        {
            *first=*behind;
        }
        *second=root;
    }
    *behind = root;
    find_wrong_node_of_bsts(root->right,behind,first,second);
}
void func(struct node_of_bst *root)
{
    struct node_of_bst* behind=NULL;
    struct node_of_bst* first=NULL;
    struct node_of_bst* second=NULL;

    find_wrong_node_of_bsts(root,&behind,&first,&second);
    if(first!= NULL && second!=NULL)
    {
        swap(&(first->data),&(second->data));
    }

}

int main()
{
    struct node_of_bst * root=new_node_of_bst(25);
        
        root->left = new_node_of_bst(20);
    root->right = new_node_of_bst(36);
    
    root->left->left = new_node_of_bst(10);
    root->left->right = new_node_of_bst(22);
    
    root->left->left->left = new_node_of_bst(5);
    root->left->left->right = new_node_of_bst(12);
    
    root->right->left = new_node_of_bst(30);
    root->right->right = new_node_of_bst(40);
    
    root->right->left->left = new_node_of_bst(28);
    root->right->right->left = new_node_of_bst(32);
    root->right->right->right = new_node_of_bst(64);
    

     printf("\nInorder traversal of orignal tree");
    inorder(root);
    func(root); 
    printf("\nInorder traversal of final tree after fixation in orignal tree");
    inorder(root);
}